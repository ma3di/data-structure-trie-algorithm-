from tkinter import *
from tkinter import ttk
from core import search
from tkinter.font import Font

win = Tk()

win.geometry("700x300")

style= ttk.Style()
style.theme_use('clam')
style.configure("TCombobox", background= "white")
font = Font(family = "Console", size = 20)

win.option_add("*TCombobox*Listbox*Font", font)
win.option_add("*TCombobox**Height", 100)

label=ttk.Label(win, text= "لطفا کلمه مورد نظر خود را وارد کنید",
font= ('Aerial 11'))
label.pack(pady=20)

def update(*args):
    value = var.get()
    data = search(value)
    newvalues = []
    for d in data:
        newvalues.append('%s (%d)'%(d[0],d[1]))
    
    cb['values'] = newvalues
    

a_set=[]

var = StringVar()
var.trace('w', update)

cb = ttk.Combobox(win, width= 50, textvariable=var)
cb.pack()

win.mainloop()
