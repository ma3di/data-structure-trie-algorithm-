class TrieNode:
    def __init__(self, ch):
        self.ch = ch
        self.counts = 0
        self.is_end = False
        self.childs = {}


class Trie(object):

    def __init__(self):

        self.root = TrieNode("")

    def fill(self, file):
        f = open(file, "r")

        while True:
            st = f.readline()
            if len(st) == 0:
                break

            self.insert(st.strip())

    def dfs(self, node, prefix):
        if node.is_end:
            self.output.append((prefix + node.ch, node.counts))

        for child in node.childs.values():
            self.dfs(child, prefix + node.ch)

    def insert(self, word):
        node = self.root

        for ch in word:
            if ch in node.childs:
                node = node.childs[ch]
            else:
                new_node = TrieNode(ch)
                node.childs[ch] = new_node
                node = new_node

        node.is_end = True

        node.counts += 1


    def query(self, x):
        self.output = []
        node = self.root

        for ch in x:
            if ch in node.childs:
                node = node.childs[ch]
            else:
                return []

        self.dfs(node, x[:-1])

        return sorted(self.output, key=lambda x: x[1], reverse=True)
