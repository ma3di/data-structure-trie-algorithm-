from tire import Trie

#file name
FILE = 'data'
#root module
root = Trie()
# fill data in file
root.fill(FILE)

def search(letter):
    return root.query(letter)

def node_str(node):
    return '\033[0m%s\t\033[32m%d\033[0m' % (node[0],node[1])
    
def search_print(data):
    for item in data:
        print(node_str(item))