import tkinter as tk 
from tkinter import ttk 
from core import search

window = tk.Tk() 
window.title('پروژه ساختمان داده(قوسیان)') 
window.geometry('700x250') 
  
ll = ttk.Label(window,width = 50, text = "لطفا کلمه مورد نظر خود را وارد کنید.",  font = ("Times New Roman", 15)) 
ll.place(x = 100, y = 50)
  
def update(*args):
    value = var.get()
    
    data = search(value)
    newvalues = []
    for d in data:
        newvalues.append('%s (%d)'%(d[0],d[1]))
    
    cb['values'] = newvalues
    

var = tk.StringVar() 
var.trace('w', update)
cb = ttk.Combobox(window, width = 50, textvariable = var) 
cb.place(x = 100, y = 100)

window.mainloop() 