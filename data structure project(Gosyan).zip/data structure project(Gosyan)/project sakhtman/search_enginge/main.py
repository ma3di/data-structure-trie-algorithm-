from faker import Faker
fake = Faker()

file = open('data','w')

# create dummy data file
for _ in range(2000):
    file.write(f'{fake.name()}\n'.lower())